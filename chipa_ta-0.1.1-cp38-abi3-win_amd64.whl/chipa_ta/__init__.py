from .chipa_ta import *

__doc__ = chipa_ta.__doc__
if hasattr(chipa_ta, "__all__"):
    __all__ = chipa_ta.__all__